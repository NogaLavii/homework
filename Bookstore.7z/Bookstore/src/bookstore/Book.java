package bookstore;

public class Book {

}
